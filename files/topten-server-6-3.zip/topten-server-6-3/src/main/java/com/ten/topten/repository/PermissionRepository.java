package com.ten.topten.repository;

import com.ten.topten.entity.Permission;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:51 2024/5/19
 * @modified by:
 */
@RepositoryRestResource(exported = false)
public interface PermissionRepository extends CrudRepository<Permission, Short> {

  @Query(value = "SELECT p.* FROM permission_config pc inner join permission p " +
          "on pc.perm_id = p.id " +
          "WHERE pc.role_id = ?1 and pc.project_id = ?2", nativeQuery = true)
  List<Permission> listPermissionsByCriteria(Short roleId, Short projectId);
}

