package com.ten.topten.common.exception;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 2:34 PM 2019/9/4
 * @modified by: com.mcp.topten.common.exception 2022/9/21
 */

public class LogFormat {
    public static String apiErrorDetail(ApiException e) {
        return String.format("**** Custom API exception -- Code: %s, Message: %s, Exception Cause: %s", e.getCode(), e.getMsg(), e.getMessage());
    }
}



