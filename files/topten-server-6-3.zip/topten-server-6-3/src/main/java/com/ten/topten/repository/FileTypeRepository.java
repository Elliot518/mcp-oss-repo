package com.ten.topten.repository;

import com.ten.topten.entity.FileType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

/**
 * @author Elliot
 * @developer
 * @description
 * @date Created in 2024年03月21日 10:49
 * @modified_by
 */
@RepositoryRestResource(path = "fileTypeEntities")
public interface FileTypeRepository extends CrudRepository<FileType, Short> {
}
