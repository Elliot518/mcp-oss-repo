package com.ten.topten.common.api;

/**
 * Encapsulated API error code
 * Created by Elliot on 2022/9/21
 */

public interface IErrorCode {
    String getCode();

    String getMessage();
}


