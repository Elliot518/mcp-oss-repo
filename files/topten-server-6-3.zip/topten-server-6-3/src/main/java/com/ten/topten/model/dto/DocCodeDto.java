package com.ten.topten.model.dto;

import java.time.LocalDateTime;

/**
 * @description:
 * @date: Created in 11:05 2024/2/28
 * @modified by:
 */
public interface DocCodeDto {
  Short getId();
  String getCode();
  String getName();
  String getDefinition();
  LocalDateTime getCreated();
  String getCreator();
  LocalDateTime getUpdated();
  String getUpdateBy();
}
