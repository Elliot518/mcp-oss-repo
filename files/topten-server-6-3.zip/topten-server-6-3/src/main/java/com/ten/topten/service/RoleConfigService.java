package com.ten.topten.service;

import com.ten.topten.entity.RoleConfig;
import com.ten.topten.model.dto.RoleConfigDto;
import com.ten.topten.repository.UprRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 11:33 2024/6/21
 * @modified by:
 */
@Service
public class RoleConfigService {

  @Autowired
  private UprRepository uprRepository;

  public void updateRoleConfig(Long userId, List<RoleConfigDto> newRoleConfigs) {
    // Delete existing records
    uprRepository.deleteByUserId(userId);

    // Set created and revised date for new records
    LocalDateTime now = LocalDateTime.now();
    List<RoleConfig> roleConfigEntities = newRoleConfigs.stream().map(dto -> {
      RoleConfig roleConfig = new RoleConfig();
      roleConfig.setUserId(userId);
      roleConfig.setProjectId(dto.getProjectId());
      roleConfig.setRoleId(dto.getRoleId());
      roleConfig.setCreated(now);
      roleConfig.setRevised(now);
      roleConfig.setCreator("Admin");
      roleConfig.setRevisedBy("Admin");
      return roleConfig;
    }).collect(Collectors.toList());

    // Save new records
    uprRepository.saveAll(roleConfigEntities);
  }
}


