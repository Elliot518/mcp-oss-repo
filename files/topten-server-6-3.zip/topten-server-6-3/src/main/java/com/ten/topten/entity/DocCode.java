package com.ten.topten.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:33 2024/2/27
 * @modified by:
 */
@Data
@Entity
public class DocCode {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Short id;

  private String code;

  private String name;

  private String definition;

  private LocalDateTime created;

  private String creator;

  private LocalDateTime updated;

  private String updateBy;
}
