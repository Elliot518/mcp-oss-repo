package com.ten.topten.common.api;

/**
 * @ author: Elliot
 * Created by Elliot on 2022/9/21
 */

public enum ResultCode implements IErrorCode {
    /* 成功: 0 */
    SUCCESS("0", "Successful Operation"),

    /* 常用错误 */
    INTERNAL_SERVER_ERROR("500", "Internal Server Error"),
    UNAUTHORIZED("401", "Not logged in or the token has expired"),
    FORBIDDEN("403", "No relevant permissions"),
    DEFAULT_AUTH("5100", "Certificate authority rollback"),

    /* Parameter Errors: 1000 - 1999 */
    PARAM_INVALID("1000", "Parameters validation failed"),

    /* User Errors: 2000 - 2999 */
    USER_NOT_LOGIN("2000", "User is not logged in");

    private String code;
    private String message;

    private ResultCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
