package com.ten.topten.controller;

import com.ten.topten.common.api.ResponseResult;
import com.ten.topten.entity.RoleConfig;
import com.ten.topten.model.dto.RoleConfigDto;
import com.ten.topten.model.dto.UprDto;
import com.ten.topten.repository.UprRepository;
import com.ten.topten.service.MatrixService;
import com.ten.topten.service.RoleConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 09:44 2024/6/13
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/admin")
public class AdminController {

  @Autowired
  private UprRepository uprRepository;

  @Autowired
  private MatrixService matrixService;

  @Autowired
  private RoleConfigService roleConfigService;

  @GetMapping("/upr/{userId}")
  public List<UprDto> listUPRbyUserId(@PathVariable Long userId) {
    return uprRepository.listUPRbyUserId(userId);
  }

  @GetMapping("/roleMatrix")
  public Map<String, Map<String, Boolean>> getRoleMatrix(@RequestParam Long userId) {
    return matrixService.getMatrixForUser(userId);
  }

  @PutMapping("/upr")
  public void updateRoleConfig(@RequestParam Long userId, @RequestBody List<RoleConfigDto> newRoleConfigs) {
    roleConfigService.updateRoleConfig(userId, newRoleConfigs);
  }
}
