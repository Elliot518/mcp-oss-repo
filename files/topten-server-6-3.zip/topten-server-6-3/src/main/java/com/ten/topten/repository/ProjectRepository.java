package com.ten.topten.repository;

import com.ten.topten.entity.Project;
import com.ten.topten.model.dto.ProjectDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:29 2024/5/23
 * @modified by:
 */
@RepositoryRestResource(exported = false)
public interface ProjectRepository extends JpaRepository<Project, Short> {
  @Query(value = """
            SELECT rc.project_id as projectId, rc.role_id as roleId, r.rolename, p.route_path as routePath, p.name as projectName, p.caption as projectCaption
            FROM role_config rc inner join `role` r on rc.role_id = r.id inner join project p
            on rc.project_id = p.id WHERE rc.user_id = ?1
          """, nativeQuery = true)
  List<ProjectDto> listProjectsByUserId(Long userId);
}
