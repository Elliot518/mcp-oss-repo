package com.ten.topten.controller;

import com.ten.topten.common.api.ResponseResult;
import com.ten.topten.entity.Permission;
import com.ten.topten.repository.PermissionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:50 2024/5/19
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/permissions")
public class PermissionController {

  @Autowired
  private PermissionRepository permissionRepository;

  @GetMapping
  public List<Permission> listPermissionsByRoleAndProject(@RequestParam(name = "roleId") Short roleId, @RequestParam(name = "projectId") Short projectId) {
    return permissionRepository.listPermissionsByCriteria(roleId, projectId);
  }
}
