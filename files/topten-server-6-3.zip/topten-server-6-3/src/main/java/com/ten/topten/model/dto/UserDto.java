package com.ten.topten.model.dto;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 11:50 2024/5/16
 * @modified by:
 */
public interface UserDto {
  Long getId();
  String getUsername();
  String getPassword();
  Short getRoleId();
  LocalDateTime getPwExpiry();
}
