package com.ten.topten.model.response;

import lombok.Data;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:13 2024/5/13
 * @modified by:
 */
@Data
public class LoginResponse {
  private String username;
  private String token;

  private Long userId;
}

