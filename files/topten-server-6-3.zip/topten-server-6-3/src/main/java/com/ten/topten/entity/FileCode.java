package com.ten.topten.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.Type;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 15:33 2024/2/27
 * @modified by:
 */
@Data
@Entity
public class FileCode {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Short id;

  private String code;

  private String name;

  private Short catId;

  private Short typeId;

  private String description;

  @Column(columnDefinition = "TINYINT(1)")
  private boolean active;

  private LocalDateTime created;

  private String creator;

  private LocalDateTime updated;

  private String updateBy;
}
