package com.ten.topten.model.dto;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 22:23 2024/6/13
 * @modified by:
 */
public interface UprDto {
  Short getId();
  Long getUserId();
  Short getProjectId();
  Short getRoleId();
  String getUsername();
  String getProjectName();
  String getRolename();
}


