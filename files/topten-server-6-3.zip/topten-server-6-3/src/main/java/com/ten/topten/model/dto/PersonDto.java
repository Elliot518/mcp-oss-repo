package com.ten.topten.model.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 23:18 2024/1/16
 * @modified by:
 */
@Data
public class PersonDto {
  @NotBlank(message = "person name can not be empty")
  private String name;

  private int age;
}

