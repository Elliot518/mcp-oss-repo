package com.ten.topten.controller;

import com.ten.topten.common.api.ResponseResult;
import com.ten.topten.model.dto.DocCodeDto;
import com.ten.topten.repository.DocCodeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @description:
 * @date: Created in 11:22 2024/2/28
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/docCodes")
public class DocCodeController {

  @Autowired
  private DocCodeRepository docCodeRepository;

  @GetMapping
  public List<DocCodeDto> listAllDocCodes() {
    log.info("Start to list all doc codes ...");
    return docCodeRepository.listAllDocCodes();
  }
}

