package com.ten.topten;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToptenServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToptenServerApplication.class, args);
	}

}
