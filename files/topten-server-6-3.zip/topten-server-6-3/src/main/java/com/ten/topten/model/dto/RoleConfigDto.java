package com.ten.topten.model.dto;

import lombok.Data;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 11:43 2024/6/21
 * @modified by:
 */
@Data
public class RoleConfigDto {
  private Short projectId;
  private Short roleId;
}
