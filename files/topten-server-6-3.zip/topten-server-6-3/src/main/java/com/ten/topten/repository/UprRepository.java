package com.ten.topten.repository;

import com.ten.topten.entity.RoleConfig;
import com.ten.topten.model.dto.UprDto;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 22:34 2024/6/13
 * @modified by:
 */
@RepositoryRestResource(exported = false)
public interface UprRepository extends CrudRepository<RoleConfig, Short> {
  @Query(value = """
           SELECT rc.id, rc.user_id as userId, rc.project_id as projectId, rc.role_id as roleId, u.username, p.name as projectName, r.rolename
           FROM role_config rc inner join `role` r on rc.role_id = r.id
           inner join `user` u on rc.user_id = u.id inner join project p
           on rc.project_id = p.id
           where rc.user_id = ?1
          """, nativeQuery = true)
  List<UprDto> listUPRbyUserId(Long userId);

  @Transactional
  @Modifying
  @Query("DELETE FROM RoleConfig rc WHERE rc.userId = ?1")
  void deleteByUserId(Long userId);
}
