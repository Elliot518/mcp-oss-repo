package com.ten.topten.repository;

import com.ten.topten.entity.FileCategory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 16:13 2024/2/27
 * @modified by:
 */
@RepositoryRestResource(path = "fileCategoryEntities")
public interface FileCategoryRepository extends CrudRepository<FileCategory, Short> {
}
