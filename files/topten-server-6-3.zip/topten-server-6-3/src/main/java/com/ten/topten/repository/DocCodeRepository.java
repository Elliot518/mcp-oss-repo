package com.ten.topten.repository;

import com.ten.topten.entity.DocCode;
import com.ten.topten.model.dto.DocCodeDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @description:
 * @date: Created in 11:20 2024/2/28
 * @modified by:
 */
@RepositoryRestResource(path = "docCodeEntities")
public interface DocCodeRepository extends JpaRepository<DocCode, Short> {
  @Query("SELECT d.id AS id, d.code AS code, d.name AS name, d.definition AS definition, " +
          "d.created AS created, d.creator AS creator, d.updated AS updated, d.updateBy AS updateBy " +
          "FROM DocCode d")
  List<DocCodeDto> listAllDocCodes();
}
