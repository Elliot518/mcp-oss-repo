package com.ten.topten.controller;

import com.ten.topten.common.api.ResponseResult;
import com.ten.topten.model.dto.ProjectDto;
import com.ten.topten.repository.ProjectRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:39 2024/5/23
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/projects")
public class ProjectController {

  @Autowired
  private ProjectRepository projectRepository;

  @GetMapping
  public List<ProjectDto> listProjectsByUserId(@RequestParam(name = "userId") Long userId) {
    return projectRepository.listProjectsByUserId(userId);
  }
}
