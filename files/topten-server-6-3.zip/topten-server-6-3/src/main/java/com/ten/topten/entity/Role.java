package com.ten.topten.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:21 2024/6/19
 * @modified by:
 */
@Data
@Entity
public class Role {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Short id;

  @Column(nullable = false, unique = true)
  private String rolename;

  @Column(nullable = false)
  private LocalDateTime created;

  @Column(nullable = false)
  private String creator;

  private LocalDateTime revised;

  private String revisedBy;
}

