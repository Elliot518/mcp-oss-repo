package com.ten.topten.repository;

import com.ten.topten.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:24 2024/6/19
 * @modified by:
 */
public interface RoleRepository extends JpaRepository<Role, Short> {
}

