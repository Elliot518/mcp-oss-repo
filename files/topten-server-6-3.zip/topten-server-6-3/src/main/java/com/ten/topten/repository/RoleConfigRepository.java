package com.ten.topten.repository;

import com.ten.topten.entity.RoleConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:24 2024/6/19
 * @modified by:
 */
public interface RoleConfigRepository extends JpaRepository<RoleConfig, Short> {
  List<RoleConfig> findByUserId(Long userId);
}

