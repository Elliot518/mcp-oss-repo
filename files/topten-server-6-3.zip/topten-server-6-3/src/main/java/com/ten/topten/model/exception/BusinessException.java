package com.ten.topten.model.exception;

import com.ten.topten.common.exception.ApiException;

/**
 * @author Elliot
 * @description Business custom exception
 * @date Created in 2024-01-28 9:55 AM
 * @modified_by
 */
public class BusinessException extends ApiException {
    public BusinessException(BusinessResultCode resultCode) {
        super(resultCode.getCode(), resultCode.getMessage());
    }

    public BusinessException(String code, String message) {
        super(code, message);
    }
}


