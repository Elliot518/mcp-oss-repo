package com.ten.topten.repository;

import java.util.Optional;

import com.ten.topten.entity.User;
import com.ten.topten.model.dto.UserDto;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

//@RepositoryRestResource(exported = false)
@RepositoryRestResource(path = "userEntities")
public interface UserRepository extends CrudRepository<User, Long> {

	@Query(value = "SELECT * FROM user " +
					"WHERE username = ?1 AND (pw_expiry >= NOW() or pw_expiry is NULL)", nativeQuery = true)
	User findNoExpiredUserByName(String username);
}

