package com.ten.topten.controller;

import com.ten.topten.common.api.ResponseResult;
import com.ten.topten.entity.FileType;
import com.ten.topten.repository.FileTypeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Elliot
 * @developer
 * @description
 * @date Created on 2024年03月21日 10:58
 * @modified_by
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/fileTypes")
public class FileTypeController {

    @Autowired
    private FileTypeRepository fileTypeRepository;

    @GetMapping
    public Iterable<FileType> listAllFileTypes() {
        log.info("Start to list all file types ...");
        return fileTypeRepository.findAll();
    }
}

