package com.ten.topten.common.exception;

import com.ten.topten.common.api.Result;
import jakarta.validation.ConstraintViolationException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;



/**
 * @author Elliot
 * @description Global exception handler
 * @date Created in 5:56 PM 2024/01/28
 * @modified_by Elliot 2024/01/28
 */
public class BaseExceptionControllerAdvice {
    public Result<String> constraintExceptionHandler(ConstraintViolationException e) {
        return ExceptionAssistant.captureParamError(e.getMessage());
    }

    public Result<String> methodArgumentNotValidExceptionHandler(MethodArgumentNotValidException e) {
        ObjectError objectError = e.getBindingResult().getAllErrors().get(0);

        return ExceptionAssistant.captureParamError(objectError.getDefaultMessage());
    }

    public Result<String> apiExceptionHandler(Exception e) {
        return ExceptionAssistant.captureApiException(e);
    }

}



