package com.ten.topten.controller;

import com.ten.topten.common.api.ResponseResult;
import com.ten.topten.model.dto.FileCodeDto;
import com.ten.topten.repository.FileCodeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 11:22 2024/2/28
 * @modified by:
 */
@Slf4j
@RestController
@ResponseResult
@RequestMapping("/api/fileCodes")
public class FileCodeController {

  @Autowired
  private FileCodeRepository fileCodeRepository;

  @GetMapping
  public List<FileCodeDto> listAllFileCodes() {
    log.info("Start to list all file codes ...");
    return fileCodeRepository.listAllFileCodes();
  }
}
