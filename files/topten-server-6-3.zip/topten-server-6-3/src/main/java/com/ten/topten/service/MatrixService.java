package com.ten.topten.service;

import com.ten.topten.entity.Project;
import com.ten.topten.entity.Role;
import com.ten.topten.entity.RoleConfig;
import com.ten.topten.repository.ProjectRepository;
import com.ten.topten.repository.RoleConfigRepository;
import com.ten.topten.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 21:25 2024/6/19
 * @modified by:
 */
@Service
public class MatrixService {

  @Autowired
  private ProjectRepository projectRepository;

  @Autowired
  private RoleRepository roleRepository;

  @Autowired
  private RoleConfigRepository roleConfigRepository;

  public Map<String, Map<String, Boolean>> getMatrixForUser(Long userId) {
    List<Project> projects = projectRepository.findAll();
    List<Role> roles = roleRepository.findAll();
    List<RoleConfig> roleConfigs = roleConfigRepository.findByUserId(userId);

    Map<String, Map<String, Boolean>> matrix = new HashMap<>();

    for (Role role : roles) {
      Map<String, Boolean> projectMap = new HashMap<>();
      for (Project project : projects) {
        boolean isPresent = roleConfigs.stream()
                .anyMatch(rc -> rc.getRoleId().equals(role.getId()) && rc.getProjectId().equals(project.getId()));
        projectMap.put(project.getId() + "," + project.getCaption(), isPresent);
      }
      matrix.put(role.getId() + "," + role.getRolename(), projectMap);
    }

    return matrix;
  }
}






