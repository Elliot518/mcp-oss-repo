package com.ten.topten.model.dto;

import java.time.LocalDateTime;

/**
 * @author: Elliot
 * @description:
 * @date: Created in 11:05 2024/2/28
 * @modified by:
 */
public interface FileCodeDto {
  Short getId();
  String getCode();
  String getName();
  Short getCatId();
  Short getTypeId();
  String getCategory();
  String getTypeName();
  String getDescription();
  boolean getActive();
  LocalDateTime getCreated();
  String getCreator();
  LocalDateTime getUpdated();
  String getUpdateBy();
}
