package com.ten.topten.service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

/**
 * @author Elliot
 * @developer
 * @description
 * @date Created on 2024年03月25日 20:52
 * @modified_by
 */
@Component
public class JwtService {
    /**
        1 day in ms Should be shorter in production
    */
    static final long EXPIRATION_TIME = 86400000;

    static final String PREFIX = "Bearer";

    /**
        Generate secret key
        In production, you should read it from the application configuration
     */
    static final Key KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);

    /**
     * Generate signed JWT token
     * @author Elliot
     * @date 2024/3/25 21:02
     * @param username  parameter of getToken
     * @return java.lang.String
     */
    public String getToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(KEY).compact();
    }

    /**
     * Get a token from request Authorization header,
     * verify the token, and get username
     * @author Elliot
     * @date 2024/3/25 21:06
     * @param request  parameter of getAuthUser
     * @return java.lang.String
     */
    public String getAuthUser(HttpServletRequest request) {
        String token = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (token != null) {
            String user = Jwts.parserBuilder().setSigningKey(KEY).build()
                    .parseClaimsJws(token.replace(PREFIX, ""))
                    .getBody().getSubject();
            if (user != null)
                return user;
        }
        return null;
    }
}
