package com.ten.topten.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author Elliot
 * @developer
 * @description
 * @date Created on 2024年03月21日 10:49
 * @modified_by
 */
@Data
@Entity
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Short id;

    private String name;

    private String caption;

    private String routePath;

    private LocalDateTime created;

    private String creator;

    private LocalDateTime revised;

    private String revisedBy;
}
