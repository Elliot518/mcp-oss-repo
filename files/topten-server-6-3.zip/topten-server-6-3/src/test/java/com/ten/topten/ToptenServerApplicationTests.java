package com.ten.topten;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootTest
class ToptenServerApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void testPassword() {
		// Create an instance of BCryptPasswordEncoder
		PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

		// Password to be encrypted
		String password = "123456";

		// Encrypt the password
		String encryptedPassword = passwordEncoder.encode(password);

		// Print the encrypted password
		System.out.println("Encrypted Password: " + encryptedPassword);
	}
}
