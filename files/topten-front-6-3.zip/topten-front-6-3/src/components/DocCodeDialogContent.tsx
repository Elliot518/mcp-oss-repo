import { DocCode } from "../model/DocCodeModels";
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import { DialogContent } from "@mui/material";

type DialogFormProps = {
    docCode: DocCode;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

function DocCodeDialogContent({ docCode, handleChange }: DialogFormProps) {

    return (
        <>
            <DialogContent>
                <Stack spacing={3} mt={1}>
                    <TextField sx={{ width: '10ch' }} inputProps={{ maxLength: 2 }} label="Code" name="code" value={docCode.code} onChange={handleChange}/>
                    <TextField sx={{ width: '30ch' }} label="Name" name="name" value={docCode.name} onChange={handleChange}/>
                    <TextField sx={{ width: '50ch' }} label="Definition" name="definition" value={docCode.definition} onChange={handleChange}/>
                    <TextField sx={{ width: '30ch' }} label="Created" name="created" value={docCode.created} onChange={handleChange} style={{ display: 'none' }} />
                    <TextField sx={{ width: '20ch' }} label="Creator" name="creator" value={docCode.creator} onChange={handleChange} style={{ display: 'none' }} />
                </Stack>
            </DialogContent>
        </>
    );
}

export default DocCodeDialogContent;
