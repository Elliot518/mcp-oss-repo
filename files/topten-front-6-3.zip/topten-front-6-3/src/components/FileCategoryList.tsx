import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { getFileCategories } from "../api/FileCategoryApi";
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

type DialogFormProps = {
    categoryId: number;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

function FileCategoryList({ categoryId, handleChange }: DialogFormProps) {
    // get file category list
    const { data, error, isSuccess } = useQuery({
        queryKey: ["fileCategories"], 
        queryFn: getFileCategories
    })

    if (!isSuccess) {
        return <span>Loading...</span>
    }
    else if (error) {
        return <span>Error when fetching data...</span>
    }
    else if (data.code !== "0") {
        return <span>data.message</span>
    }
    else {
        return (
            <>
                <Box sx={{ minWidth: 120 }}>
                    <FormControl fullWidth>
                        <InputLabel id="file-category-select-label">File Category</InputLabel>
                        <Select
                            labelId="file-category-select-label"
                            id="file-category-select"
                            name = "catId"
                            value={categoryId}
                            label="File Category"
                            onChange={handleChange}
                        >
                            {data.data.map(function (item) {
                            return (
                                <MenuItem key={item.id} value={item.id}>{item.name}</MenuItem>     
                            );   
                            })}
                        </Select> 
                    </FormControl>
                </Box>
            </>
        );
    }
}

export default FileCategoryList;


