import { FileCode } from "../model/FileCodeModels";
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import { DialogContent } from "@mui/material";
import FileCategoryList from './FileCategoryList';
import FileTypeList from "./FileTypeList";
import BooleanRadio from './BooleanRadio';

/*
    We have to pass the FileCode object and the handleChange function to the component using props. 
    To do that, we need to create a new type called DialogFormProps.
*/
type DialogFormProps = {
    fileCode: FileCode;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

function FileCodeDialogContent({ fileCode, handleChange }: DialogFormProps) {

    return (
        <>
            <DialogContent>
                <Stack spacing={3} mt={1}>
                    <TextField sx={{ width: '10ch' }} inputProps={{ maxLength: 3 }} label="Code" name="code" value={fileCode.code} onChange={handleChange}/>
                    <TextField sx={{ width: '30ch' }} label="Name" name="name" value={fileCode.name} onChange={handleChange}/>
                    <TextField sx={{ width: '50ch' }} label="Description" name="description" value={fileCode.description} onChange={handleChange}/>
                    <FileCategoryList categoryId={fileCode.catId} handleChange={handleChange} />
                    <FileTypeList typeId={fileCode.typeId} handleChange={handleChange} />
                    <BooleanRadio activeValue={fileCode.active} handleChange={handleChange} />
                    <TextField sx={{ width: '30ch' }} label="Created" name="created" value={fileCode.created} onChange={handleChange} style={{ display: 'none' }} />
                    <TextField sx={{ width: '20ch' }} label="Creator" name="creator" value={fileCode.creator} onChange={handleChange} style={{ display: 'none' }} />
                </Stack>
            </DialogContent>
        </>
    );
}

export default FileCodeDialogContent;



