import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { getFileTypes } from '../api/FileTypeApi';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

type DialogFormProps = {
    typeId: number;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

function FileTypeList({ typeId, handleChange }: DialogFormProps) {
    // get file type list
    const { data, error, isSuccess } = useQuery({
        queryKey: ["fileTypes"], 
        queryFn: getFileTypes
    })

    if (!isSuccess) {
        return <span>Loading...</span>
    }
    else if (error) {
        return <span>Error when fetching data...</span>
    }
    else if (data.code !== "0") {
        return <span>data.message</span>
    }
    else {
        return (
            <>
                <Box sx={{ minWidth: 120 }}>
                    <FormControl fullWidth>
                        <InputLabel id="file-type-select-label">File Type</InputLabel>
                        <Select
                            labelId="file-type-select-label"
                            id="file-type-select"
                            name = "typeId"
                            value={typeId}
                            label="File Type"
                            onChange={handleChange}
                        >
                            {data.data.map(function (item) {
                            return (
                                <MenuItem key={item.id} value={item.id}>{item.typename}</MenuItem>     
                            );   
                            })}
                        </Select> 
                    </FormControl>
                </Box>
            </>
        );
    }
}

export default FileTypeList;


