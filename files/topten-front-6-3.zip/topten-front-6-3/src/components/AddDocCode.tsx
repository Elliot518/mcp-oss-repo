import { useState } from 'react';
import { DocCode, DocCodeResponse } from "../model/DocCodeModels";
import { getISODateString } from '../util/TimeUtil';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import DocCodeDialogContent from './DocCodeDialogContent';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { addDocCode } from '../api/DocCodeApi';
import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';
import AddIcon from '@mui/icons-material/Add';
import Fab from '@mui/material/Fab';

function AddDocCode() {
    const [docCode, setDocCode] = useState<DocCode>({
        id: 0,
        code: '',
        name: '',
        definition: '',
        created: getISODateString(),
        creator: 'Admin',
        updated: getISODateString(),
        updateBy: 'Admin',
    });

    const [open, setOpen] = useState(false);
    const [snackOpen, setSnackOpen] = useState(false);

    const queryClient = useQueryClient();

    const handleClickOpen = () => {
        setOpen(true);
    }

    const handleClose = () => {
        setOpen(false);
    }

    const handleSnackClose = () => {
        setSnackOpen(false);
    }

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        setDocCode(prev => ({
            ...prev,
            [name]: value
        }));
    }

    const { mutate } = useMutation(addDocCode, {
        onSuccess: (data: DocCodeResponse) => {
            setSnackOpen(true);
            setOpen(false);
            queryClient.invalidateQueries({ queryKey: ['docCodes'] });
        },
        onError: (err) => {
            console.error(err);
        },
    });

    const handleAdd = async () => {
        mutate(docCode);
    }

    return (
        <>
            <Fab variant="extended" size="medium" color="primary" onClick={handleClickOpen}>
                <AddIcon /> Add DocCode
            </Fab>
            <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
                <DialogTitle>Add DocCode</DialogTitle>
                <DocCodeDialogContent docCode={docCode} handleChange={handleChange} />
                <DialogActions>
                    <Button onClick={handleClose} color="primary">Cancel</Button>
                    <Button onClick={handleAdd} color="primary">Save</Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                open={snackOpen}
                autoHideDuration={2000}
                onClose={handleSnackClose}
                message="Data saved" />
        </>
    );
}

export default AddDocCode;
