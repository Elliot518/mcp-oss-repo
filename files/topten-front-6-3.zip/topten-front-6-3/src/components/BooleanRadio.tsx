import React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';

type DialogFormProps = {
  activeValue: boolean;
  handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

function BooleanRadio({ activeValue, handleChange }: DialogFormProps) {

  return (
    <>
      <FormControl component="fieldset">
        <RadioGroup name="active" value={activeValue.toString()} onChange={handleChange}>
          <FormControlLabel value="true" control={<Radio />} label="Active" />
          <FormControlLabel value="false" control={<Radio />} label="Inactive" />
        </RadioGroup>
      </FormControl>
    </>
  );
}

export default BooleanRadio;

