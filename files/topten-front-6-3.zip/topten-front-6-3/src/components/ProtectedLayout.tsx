// src/components/ProtectedLayout.tsx

import React, { useEffect, useState } from 'react';
import { Navigate, Route, Routes, Outlet, useNavigate, useLocation } from 'react-router-dom';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { fetchRoutes } from '../api/RoutesApi';
import Sidebar from './Sidebar';
import { ProjectDto } from '../model/ProjectModels';
import { DEFAULT_ROUTE } from '../model/ProjectConst';
import { renderProjectComponent } from './RouteRenderer';
import Dashboard from './Dashboard';

const ProtectedLayout: React.FC = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [projects, setProjects] = useState<ProjectDto[]>([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const location = useLocation();

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    useEffect(() => {
        const fetchProjectRoutes = async () => {
            try {
                const userId = Number(sessionStorage.getItem("userId"));
                const fetchedProjects = await fetchRoutes(userId);
                setProjects(fetchedProjects);
                setLoading(false);
            } catch (error) {
                console.error('Error fetching projects:', error);
                setLoading(false);
            }
        };

        fetchProjectRoutes();
    }, []);

    const handleLogout = () => {
        sessionStorage.clear();
        navigate('/login');
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    const isDashboard = location.pathname === '/dashboard';

    return (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
            <AppBar position="static" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
                <Toolbar>
                    <Typography variant="h6" sx={{ flexGrow: 1 }}>
                        TopTen Front
                    </Typography>
                    {isDashboard ? (
                        <Button color="inherit" onClick={handleLogout}>Log out</Button>
                    ) : (
                        <Button color="inherit" onClick={() => navigate('/dashboard')}>Close</Button>
                    )}
                </Toolbar>
            </AppBar>
            <div style={{ display: 'flex', flexGrow: 1 }}>
                {isDashboard && (
                    <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} projects={projects} />
                )}
                <main
                    style={{
                        flexGrow: 1,
                        padding: '1rem',
                        marginLeft: isSidebarOpen && isDashboard ? '240px' : '72px',
                        transition: 'margin-left 0.3s',
                    }}
                >
                    <Routes>
                        <Route path="/" element={<Navigate to={DEFAULT_ROUTE} />} />
                        <Route path="/dashboard" element={<Dashboard />} />
                        {projects.map((project) => (
                            <Route
                                key={project.projectId}
                                path={project.routePath}
                                element={renderProjectComponent(project)}
                            />
                        ))}
                        <Route path="*" element={<Navigate to={DEFAULT_ROUTE} />} />
                    </Routes>
                    <Outlet />
                </main>
            </div>
        </div>
    );
};

export default ProtectedLayout;
