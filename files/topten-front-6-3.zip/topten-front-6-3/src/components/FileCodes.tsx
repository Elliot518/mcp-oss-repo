// src/components/FileCodes.tsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { listAllFileCodes, deleteFileCode } from '../api/FileCodeApi';
import { getPermissions } from '../api/PermissionApi';
import { Permission } from '../model/PermissionModels';
import { DataGrid, GridColDef, GridToolbar, GridCellParams } from '@mui/x-data-grid';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import Grid from '@mui/material/Grid';
import Snackbar from '@mui/material/Snackbar';
import AddFileCode from './AddFileCode';
import EditFileCode from './EditFileCode';
import Tooltip from '@mui/material/Tooltip';
import { ADD, EDIT, DELETE, STATUS } from '../model/PermConst';

// Create a new type for the props that we can receive in the FileCodes component
type FileCodesProps = {
    roleId: number;
    projectId: number;
}

function FileCodes({ roleId, projectId }: FileCodesProps) {
    // create a boolean state called "open" to judge whether to show the toast or not after the component initialization
    const [open, setOpen] = useState(false);
    const [permsVisibility, setPermsVisibility] = useState({
        // Hide columns edit and delete, the other columns will remain visible
        edit: false,
        delete: false,
        active: false
    });

    // state to control AddFileCode component visibility
    const [showAddFileCode, setShowAddFileCode] = useState(false);

    const queryClient = useQueryClient();
    const navigate = useNavigate();

    // get operations list by user id and project id
    useEffect(() => {
        const fetchOperations = async () => {
            console.log(`roleId: ${roleId}, projectId: ${projectId}`)
            if (roleId && projectId) {
                try {
                    const permList: Permission[] = await getPermissions(roleId, projectId);
                    console.log("Fetched permissions:", permList);
                    const permNames = permList.map(p => p.name);
                    setPermsVisibility({
                        edit: permNames.includes(EDIT),
                        delete: permNames.includes(DELETE),
                        active: permNames.includes(STATUS),
                    });
                    // show AddFileCode by permission logic
                    setShowAddFileCode(permNames.includes(ADD));
                } catch (error) {
                    console.error('Error fetching operations:', error);
                }
            } else {
                console.error('User ID or Project ID not found');
            }
        };

        fetchOperations();
    }, [roleId, projectId]);

    // Use the useQuery hook to fetch data
    const { data, error, isSuccess } = useQuery({
        queryKey: ["fileCodes"], 
        queryFn: listAllFileCodes
    });

    // Use the React Query useMutation hook to handle deletion
    const { mutate } = useMutation(deleteFileCode, {
        onSuccess: () => {
            // once the deletion is successful, immediately set the open status to true
            setOpen(true);
            // every time a file code is deleted, all the file codes are fetched again
            queryClient.invalidateQueries({ queryKey: ['fileCodes'] });
        },
        onError: (err) => {
            console.error(err);
        },
    });

    // define grid columns
    const columns: GridColDef[] = [
        { field: 'code', headerName: 'Code', width: 100 },
        { field: 'name', headerName: 'Name', width: 150 },
        { field: 'category', headerName: 'Category', width: 150 },
        { field: 'typeName', headerName: 'Type', width: 150 },
        { field: 'description', headerName: 'Description', width: 250 },
        { field: 'created', headerName: 'Created', width: 150 },
        { field: 'creator', headerName: 'Creator', width: 150 },
        { 
            field: 'active', 
            headerName: 'Status', 
            width: 80, 
            hide: !permsVisibility.active,
            renderCell: (params: GridCellParams) => (
                <span>{params.value ? 'active' : 'inactive'}</span>
            )
        },
        {
            field: 'edit',
            headerName: '',
            width: 90,
            sortable: false,
            filterable: false,
            disableColumnMenu: true,
            renderCell: (params: GridCellParams) =>
                <EditFileCode fileCodeData={params.row} />,
            hide: !permsVisibility.edit
        },
        {
            field: 'delete',
            headerName: '',
            width: 90,
            sortable: false,
            filterable: false,
            disableColumnMenu: true,
            renderCell: (params: GridCellParams) => (
                <Tooltip title="Delete FileCode">
                    <IconButton aria-label="delete" size="small"
                        onClick={() => {
                            if (window.confirm(`Are you sure you want to delete ${params.row.code} ${params.row.name}?`)) {
                                mutate(params.row);
                            } 
                        }}
                    >
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </Tooltip>          
            ),
            hide: !permsVisibility.delete
        }
    ];

    // Use conditional rendering to check if the fetch is successful
    if (!isSuccess) {
        return <span>Loading...</span>;
    } else if (error) {
        return <span>Error when fetching file codes...</span>;
    } else if (data.code !== "0") {
        return <span>{data.message}</span>;
    } else {
        // if the open state is true, we'll show the Snackbar component
        return ( 
            <>
                <Grid container justifyContent="space-between" alignItems="center">
                    <Grid item>
                        {showAddFileCode && <AddFileCode />}
                    </Grid>
                </Grid>
                <DataGrid
                    columnVisibilityModel={permsVisibility}
                    rows={data.data}
                    columns={columns}
                    getRowId={row => row.id}
                    slots={{ toolbar: GridToolbar }} 
                />
                <Snackbar
                    open={open}
                    autoHideDuration={2000}
                    onClose={() => setOpen(false)}
                    message="Data deleted" />
            </>
        );
    }
}

export default FileCodes;
