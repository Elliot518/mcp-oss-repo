// src/RoutesConfig.tsx
import React, { useEffect, useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { fetchRoutes } from '../api/RoutesApi';
import { ProjectDto } from '../model/ProjectModels';
import Sidebar from './Sidebar';
import { renderProjectComponent } from './RouteRenderer';

const RoutesConfig: React.FC = () => {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [projects, setProjects] = useState<ProjectDto[]>([]);
    const [loading, setLoading] = useState(true);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    useEffect(() => {
        const fetchProjectRoutes = async () => {
            try {
                const userId = Number(sessionStorage.getItem("userId"));
                const fetchedProjects = await fetchRoutes(userId);
                setProjects(fetchedProjects);
                setLoading(false);
            } catch (error) {
                console.error('Error fetching projects:', error);
                setLoading(false);
            }
        };

        fetchProjectRoutes();
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <div style={{ display: 'flex' }}>
            <Sidebar isOpen={isSidebarOpen} toggleSidebar={toggleSidebar} projects={projects} />
            <main
                style={{
                    flexGrow: 1,
                    padding: '1rem',
                    marginLeft: isSidebarOpen ? '240px' : '72px',
                    transition: 'margin-left 0.3s',
                }}
            >
                <Routes>
                    {projects.map((project) => (
                        <Route
                            key={project.projectId}
                            path={project.routePath}
                            element={renderProjectComponent(project)}
                        />
                    ))}
                </Routes>
            </main>
        </div>
    );
};

export default RoutesConfig;

