import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import DescriptionIcon from '@mui/icons-material/Description';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import { ProjectDto } from '../model/ProjectModels';
import { styled } from '@mui/material/styles';
import { FILE_CODE, PROJECTS_ADMIN } from '../model/ProjectConst';

type SidebarProps = {
    isOpen: boolean;
    toggleSidebar: () => void;
    projects: ProjectDto[];
};

const drawerWidth = 240;
const closedDrawerWidth = 72;

const CustomDrawer = styled(Drawer)(({ theme }) => ({
    '& .drawer-open': {
        width: drawerWidth,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    },
    '& .drawer-closed': {
        width: closedDrawerWidth,
        transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
        }),
        overflowX: 'hidden',
    },
}));

const Sidebar: React.FC<SidebarProps> = ({ isOpen, toggleSidebar, projects }) => {
    const location = useLocation();
    
    const isActive = (path: string) => location.pathname === path;

    return (
        <CustomDrawer
            variant="permanent"
            open={isOpen}
            className={isOpen ? 'drawer-open' : 'drawer-closed'}
        >
            <div style={{ display: 'flex', alignItems: 'center', padding: '8px', justifyContent: isOpen ? 'flex-end' : 'center' }}>
                <IconButton onClick={toggleSidebar}>
                    <MenuIcon />
                </IconButton>
            </div>
            <List>
                {projects.map((project) => (
                    <ListItem
                        button
                        component={Link}
                        to={project.routePath}
                        key={project.projectId}
                        selected={isActive(project.routePath)}
                        sx={{
                            '&.Mui-selected': {
                                backgroundColor: '#90caf9', // Lighter blue color
                                '&:hover': {
                                    backgroundColor: '#64b5f6', // Slightly darker on hover
                                },
                            },
                        }}
                    >
                        <ListItemIcon>
                            {project.projectName === FILE_CODE ? <InsertDriveFileIcon /> : <DescriptionIcon />}
                        </ListItemIcon>
                        <ListItemText primary={project.projectCaption} sx={{ display: isOpen ? 'block' : 'none' }} />
                    </ListItem>
                ))}
            </List>
        </CustomDrawer>
    );
};

export default Sidebar;
