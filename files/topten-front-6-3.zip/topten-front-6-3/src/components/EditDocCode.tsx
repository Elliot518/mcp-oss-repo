import { useState } from 'react';
import { DocCode, DocCodeResponse } from "../model/DocCodeModels";
import { getISODateString, convertToISODateString } from '../util/TimeUtil';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import DocCodeDialogContent from './DocCodeDialogContent';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { updateDocCode } from '../api/DocCodeApi';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import Snackbar from '@mui/material/Snackbar';

type EditDocCodeProps = {
    docCodeData: DocCode;
}

function EditDocCode({ docCodeData }: EditDocCodeProps) {
    const [docCode, setDocCode] = useState<DocCode>({
        ...docCodeData,
        created: convertToISODateString(docCodeData.created, 'Asia/Shanghai'),
        updated: getISODateString(),
        updateBy: "Admin",
    });

    const [open, setOpen] = useState(false);
    const [show, setShow] = useState(false);
    const [snackOpen, setSnackOpen] = useState(false);

    const queryClient = useQueryClient();

    const handleClickOpen = () => {
        setShow(true);
    }

    const handleClose = () => {
        setShow(false);
    }

    const handleSnackClose = () => {
        setSnackOpen(false);
    }

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        setDocCode(prev => ({
            ...prev,
            [name]: value
        }));
    }

    const { mutate } = useMutation(updateDocCode, {
        onSuccess: (data: DocCodeResponse) => {
            setSnackOpen(true);
            setShow(false);
            queryClient.invalidateQueries({ queryKey: ['docCodes'] });
        },
        onError: (err) => {
            console.error(err);
        },
    });

    const handleUpdate = async () => {
        mutate(docCode);
    }

    return (
        <>
            <IconButton aria-label="edit" onClick={handleClickOpen}>
                <EditIcon />
            </IconButton>
            <Dialog open={show} onClose={handleClose} maxWidth="sm" fullWidth>
                <DialogTitle>Edit DocCode</DialogTitle>
                <DocCodeDialogContent docCode={docCode} handleChange={handleChange} />
                <DialogActions>
                    <Button onClick={handleClose} color="primary">Cancel</Button>
                    <Button onClick={handleUpdate} color="primary">Save</Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                open={snackOpen}
                autoHideDuration={2000}
                onClose={handleSnackClose}
                message="Data saved" />
        </>
    );
}

export default EditDocCode;
