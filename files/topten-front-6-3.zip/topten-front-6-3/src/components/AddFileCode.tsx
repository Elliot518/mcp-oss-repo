import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import FileCodeDialogContent from './FileCodeDialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import { useState } from 'react';
import { FileCode } from '../model/FileCodeModels';
import { addFileCode } from '../api/FileCodeApi';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { getISODateString } from '../util/TimeUtil';
import Button from '@mui/material/Button';

function AddFileCode() {

    const queryClient = useQueryClient();

    // Declare an entity state of type FileCode that contains all fields using the useState hook
    const [fileCode, setFileCode] = useState<FileCode>({
        id: 0,
        code: '',
        name: '',
        catId: 1,
        typeId: 1,
        description: '',
        active: true,
        created: getISODateString(),
        creator: 'Admin',
        updated: '',
        updateBy: ''
    });

    // Also need an "open" state similar to the toast functionality to control the visibility of the Add dialog
    const [open, setOpen] = useState(false);

    // declare the React Query useMutation hook
    const { mutate } = useMutation(addFileCode, {
        onSuccess: () => {
            queryClient.invalidateQueries(["fileCodes"]);
        },
        onError: (err) => {
            console.error(err);
        },
    });

    // Open the modal form
    const handleClickOpen = () => {
        setOpen(true);
    };

    // Close the modal form
    const handleClose = () => {
        setOpen(false);
    };    

    // Add handleChange function dynamically updates the entity state by creating a new object with the existing state properties 
    // and updating a property based on the input element’s name and the new value entered by the user
    const handleChange = (event : React.ChangeEvent<HTMLInputElement>) => {
        setFileCode({...fileCode, [event.target.name]: event.target.value});
    }

    // save fileCode and close modal form
    const handleSave = () => {
        // trigger useMutation hook
        mutate(fileCode);

        console.log(`created time: ${getISODateString()}`)

        // init enity state
        setFileCode({ 
            id: 0,
            code: '',
            name: '',
            catId: 1,
            typeId: 1,
            description: '',
            active: true,
            created: getISODateString(),
            creator: 'Admin',
            updated: '',
            updateBy: ''
        });  

        // close modal form
        handleClose();
    }

    // All input fields should have a name attribute and a value attribute bounding to the respective field of the entity state
    return(
        <>
            <Button onClick={handleClickOpen}>New FileCode</Button>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>New FileCode</DialogTitle>
                <FileCodeDialogContent fileCode={fileCode} handleChange={handleChange} />
                <DialogActions>
                    <Button onClick={handleSave}>Save</Button>
                    <Button onClick={handleClose}>Cancel</Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default AddFileCode;