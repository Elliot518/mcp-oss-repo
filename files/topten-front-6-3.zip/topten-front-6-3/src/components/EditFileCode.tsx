import { useState } from 'react';
import { FileCode, FileCodeResponse } from "../model/FileCodeModels";
import { getISODateString, convertToISODateString } from '../util/TimeUtil';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import FileCodeDialogContent from './FileCodeDialogContent';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { updateFileCode } from '../api/FileCodeApi';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import Tooltip from '@mui/material/Tooltip';

type FormProps = {
  fileCodeData: FileCodeResponse; 
}

function EditFileCode({ fileCodeData }: FormProps) {

    // Get query client
    const queryClient = useQueryClient();

    // Define the open state if the dialog is visible or hidden
    const [open, setOpen] = useState(false);

    // Declare an entity state of type FileCode that contains all fields using the useState hook
    // Create a state for FileCode data like we did in the add functionality
    const [fileCode, setFileCode] = useState<FileCode>({
        id: 0,
        code: '',
        name: '',
        catId: 1,
        typeId: 1,
        description: '',
        active: true,
        created: getISODateString(),
        creator: 'Admin',
        updated: '',
        updateBy: ''
    });

    // Import the updateFileCode function in the EditFileCode component and use the useMutation hook to send a request
    const { mutate } = useMutation(updateFileCode, {
        onSuccess: () => {
            queryClient.invalidateQueries(["fileCodes"]);
        },
        onError: (err) => {
            console.error(err);
        }
    });

    // event handler for open the dialog
    const handleClickOpen = () => {
        console.log(fileCodeData.created);
        // In handleClickOpen function set values of the fileCode state using fileCodeData props
        setFileCode({ 
            id: fileCodeData.id,
            code: fileCodeData.code,
            name: fileCodeData.name,
            catId: fileCodeData.catId,
            typeId: fileCodeData.typeId,
            description: fileCodeData.description,
            active: fileCodeData.active,
            created: convertToISODateString(fileCodeData.created, 'Asia/Shanghai'),
            creator: fileCodeData.creator,
            updated: getISODateString(),
            updateBy: 'Admin'
        });

        setOpen(true);
    };
   
    // event handler for close the dialog
    const handleClose = () => {
        setOpen(false);
    };
  
    // event handler for save updates
    const handleSave = () => {
        mutate(fileCode);
        setFileCode({ 
            id: 0,
            code: '',
            name: '',
            catId: 1,
            typeId: 1,
            description: '',
            active: true,
            created: getISODateString(),
            creator: 'Admin',
            updated: '',
            updateBy: ''
        });  

        setOpen(false);
    }

    // Also add the handleChange function, which saves edited values to the fileCode state
    const handleChange = (event : React.ChangeEvent<HTMLInputElement>) => {
        setFileCode({...fileCode, [event.target.name]: event.target.value});
    }

    return(
        <>
            <Tooltip title="Edit FileCode">
                <IconButton aria-label="edit" size="small" onClick={handleClickOpen}>
                    <EditIcon fontSize= "small" />
                </IconButton>   
            </Tooltip>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>Edit FileCode</DialogTitle>
                <FileCodeDialogContent fileCode={fileCode} handleChange={handleChange} />
                <DialogActions>
                    <Button onClick={handleSave}>Save</Button>
                    <Button onClick={handleClose}>Cancel</Button>
                </DialogActions>
            </Dialog>
        </>
    ); 
}

export default EditFileCode;
