// src/components/RouteRenderer.tsx
import React from 'react';
import FileCodes from './FileCodes';
import DocCodes from './DocCodes';
import ProjectsAdmin from './Admin/ProjectAdmin';
import { ProjectDto } from '../model/ProjectModels';
import { FILE_CODE, DOC_CODE, PROJECTS_ADMIN } from '../model/ProjectConst';

export const renderProjectComponent = (project: ProjectDto) => {
    switch (project.projectName) {
        case FILE_CODE:
            return <FileCodes roleId={project.roleId} projectId={project.projectId} />;
        case DOC_CODE:
            return <DocCodes roleId={project.roleId} projectId={project.projectId} />;
        case PROJECTS_ADMIN:
            return <ProjectsAdmin />;
        default:
            return null;
    }
};
