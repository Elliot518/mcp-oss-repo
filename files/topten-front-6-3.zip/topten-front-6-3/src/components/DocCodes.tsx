import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { listAllDocCodes, deleteDocCode } from '../api/DocCodeApi';
import { getPermissions } from '../api/PermissionApi';
import { Permission } from '../model/PermissionModels';
import { DataGrid, GridColDef, GridToolbar, GridCellParams } from '@mui/x-data-grid';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import Grid from '@mui/material/Grid';
import Snackbar from '@mui/material/Snackbar';
import AddDocCode from './AddDocCode';
import EditDocCode from './EditDocCode';
import Tooltip from '@mui/material/Tooltip';
import { ADD, EDIT, DELETE, STATUS } from '../model/PermConst';

type DocCodesProps = {
    roleId: number;
    projectId: number;
}

function DocCodes({ roleId, projectId }: DocCodesProps) {
    const [open, setOpen] = useState(false);
    const [permsVisibility, setPermsVisibility] = useState({
        edit: false,
        delete: false,
    });

    const [showAddDocCode, setShowAddDocCode] = useState(false);

    const queryClient = useQueryClient();
    const navigate = useNavigate();

    useEffect(() => {
        const fetchOperations = async () => {
            if (roleId && projectId) {
                try {
                    const permList: Permission[] = await getPermissions(roleId, projectId);
                    const permNames = permList.map(p => p.name);
                    setPermsVisibility({
                        edit: permNames.includes(EDIT),
                        delete: permNames.includes(DELETE),
                    });
                    setShowAddDocCode(permNames.includes(ADD));
                } catch (error) {
                    console.error('Error fetching operations:', error);
                }
            } else {
                console.error('User ID or Project ID not found');
            }
        };

        fetchOperations();
    }, [roleId, projectId]);

    const { data, error, isSuccess } = useQuery({
        queryKey: ["docCodes"], 
        queryFn: listAllDocCodes
    });

    const { mutate } = useMutation(deleteDocCode, {
        onSuccess: () => {
            setOpen(true);
            queryClient.invalidateQueries({ queryKey: ['docCodes'] });
        },
        onError: (err) => {
            console.error(err);
        },
    });

    const columns: GridColDef[] = [
        { field: 'code', headerName: 'Code', width: 100 },
        { field: 'name', headerName: 'Name', width: 150 },
        { field: 'definition', headerName: 'Definition', width: 250 },
        { field: 'created', headerName: 'Created', width: 150 },
        { field: 'creator', headerName: 'Creator', width: 150 },
        {
            field: 'edit',
            headerName: '',
            width: 90,
            sortable: false,
            filterable: false,
            disableColumnMenu: true,
            renderCell: (params: GridCellParams) =>
                <EditDocCode docCodeData={params.row} />,
            hide: !permsVisibility.edit
        },
        {
            field: 'delete',
            headerName: '',
            width: 90,
            sortable: false,
            filterable: false,
            disableColumnMenu: true,
            renderCell: (params: GridCellParams) => (
                <Tooltip title="Delete DocCode">
                    <IconButton aria-label="delete" size="small"
                        onClick={() => {
                            if (window.confirm(`Are you sure you want to delete ${params.row.code} ${params.row.name}?`)) {
                                mutate(params.row);
                            } 
                        }}
                    >
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </Tooltip>          
            ),
            hide: !permsVisibility.delete
        }
    ];

    if (!isSuccess) {
        return <span>Loading...</span>;
    } else if (error) {
        return <span>Error when fetching doc codes...</span>;
    } else if (data.code !== "0") {
        return <span>{data.message}</span>;
    } else {
        return ( 
            <>
                <Grid container justifyContent="space-between" alignItems="center">
                    <Grid item>
                        {showAddDocCode && <AddDocCode />}
                    </Grid>
                </Grid>
                <DataGrid
                    columnVisibilityModel={permsVisibility}
                    rows={data.data}
                    columns={columns}
                    getRowId={row => row.id}
                    slots={{ toolbar: GridToolbar }} 
                />
                <Snackbar
                    open={open}
                    autoHideDuration={2000}
                    onClose={() => setOpen(false)}
                    message="Data deleted" />
            </>
        );
    }
}

export default DocCodes;
