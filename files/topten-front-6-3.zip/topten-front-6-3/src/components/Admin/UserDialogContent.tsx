import { User } from "../../model/UserModels";
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import { DialogContent } from "@mui/material";

type DialogFormProps = {
    user: User;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}


function UserDialogContent({ user, handleChange }: DialogFormProps) {

    return (
        <>
            <DialogContent>
                <Stack spacing={3} mt={1}>
                    <TextField sx={{ width: '20ch' }} label="Username" name="username" value={user.username} onChange={handleChange} />
                    {/* <TextField
                        label="Password"
                        name="password"
                        type="password"
                        value={user.password}
                        onChange={handleChange}
                    /> */}
                    <TextField sx={{ width: '30ch' }} label="Password Expiry" name="pwExpiry" value={user.pwExpiry} onChange={handleChange} />
                    <TextField sx={{ width: '40ch' }} label="Email Address" name="emailAddress" value={user.emailAddress} onChange={handleChange} />
                </Stack>
            </DialogContent>
        </>
    );
}

export default UserDialogContent;
