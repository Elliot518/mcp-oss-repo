import { useState } from 'react';
import { User } from '../../model/UserModels';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { updateUser } from '../../api/UserApi';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import Tooltip from '@mui/material/Tooltip';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';

type FormProps = {
    userData: User;
}

function EditUser({ userData }: FormProps) {
    const queryClient = useQueryClient();

    const [open, setOpen] = useState(false);

    const [user, setUser] = useState<User>({
        id: 0,
        username: '',
        password: '123456',
        pwExpiry: '',
        emailAddress: ''
    });

    const { mutate } = useMutation(updateUser, {
        onSuccess: () => {
            queryClient.invalidateQueries(["users"]);
        },
        onError: (err) => {
            console.error(err);
        }
    });

    const handleClickOpen = () => {
        setUser({
            id: userData.id,
            username: userData.username,
            password: userData.password,
            pwExpiry: userData.pwExpiry,
            emailAddress: userData.emailAddress
        });
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setUser({ ...user, [event.target.name]: event.target.value });
    };

    const handleSave = () => {
        mutate(user);
        setUser({
            id: 0,
            username: '',
            password: '123456',
            pwExpiry: '',
            emailAddress: ''
        });
        setOpen(false);
    };

    return (
        <>
            <Tooltip title="Edit User">
                <IconButton aria-label="edit" size="small" onClick={handleClickOpen}>
                    <EditIcon fontSize="small" />
                </IconButton>
            </Tooltip>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>Edit User</DialogTitle>
                <DialogContent>
                    <Stack spacing={3} mt={1}>
                        <TextField label="Username" name="username" value={user.username} onChange={handleChange} />
                        <TextField
                            label="Password"
                            name="password"
                            type="password"
                            value={user.password}
                            onChange={handleChange}
                        />
                        <TextField label="Password Expiry" name="pwExpiry" value={user.pwExpiry} onChange={handleChange} />
                    </Stack>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleSave}>Save</Button>
                    <Button onClick={handleClose}>Cancel</Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default EditUser;
