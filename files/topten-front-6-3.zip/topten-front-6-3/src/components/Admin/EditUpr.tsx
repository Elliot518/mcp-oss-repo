import React, { useEffect, useState } from 'react';
import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Radio from '@mui/material/Radio';
import FormControlLabel from '@mui/material/FormControlLabel';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import { getMatrixData, updateRoleConfig } from '../../api/MatrixApi'; // Import the new API function
import Grid from '@mui/material/Grid';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    '&.header': {
        backgroundColor: theme.palette.grey[200],
        fontWeight: 'bold',
    },
    '&.role': {
        backgroundColor: theme.palette.grey[300],
        fontWeight: 'bold',
    },
}));

type EditUprProps = {
    user: { id: number; username: string };
    onBack: () => void;
};

const EditUpr: React.FC<EditUprProps> = ({ user, onBack }) => {
    const [matrix, setMatrix] = useState<{ [key: string]: { [key: string]: boolean } }>({});
    const [projects, setProjects] = useState<string[]>([]);
    const [roles, setRoles] = useState<string[]>([]);
    const [selectedRoles, setSelectedRoles] = useState<{ [key: string]: string }>({});

    const navigate = useNavigate(); // Use navigate for redirection

    useEffect(() => {
        const fetchMatrixData = async () => {
            try {
                const response = await getMatrixData(user.id);
                if (response.code === "0") {
                    const data = response.data;
                    setMatrix(data);

                    // Extract project and role headers
                    const projectHeaders = Object.keys(data[Object.keys(data)[0]]);
                    const roleHeaders = Object.keys(data);

                    setProjects(projectHeaders);
                    setRoles(roleHeaders);

                    // Initialize selected roles based on the matrix data
                    const initialSelectedRoles: { [key: string]: string } = {};
                    roleHeaders.forEach(role => {
                        projectHeaders.forEach(project => {
                            if (data[role][project]) {
                                initialSelectedRoles[project] = role;
                            }
                        });
                    });
                    setSelectedRoles(initialSelectedRoles);
                } else {
                    console.error('Error fetching matrix data:', response.message);
                }
            } catch (error) {
                console.error('Error fetching matrix data:', error);
            }
        };

        fetchMatrixData();
    }, [user.id]);

    const handleRadioChange = (project: string, role: string) => {
        setSelectedRoles(prevSelectedRoles => ({
            ...prevSelectedRoles,
            [project]: role
        }));
    };

    const handleSave = async () => {
        const newRoleConfigs = Object.entries(selectedRoles).map(([project, role]) => {
            const [projectId] = project.split(',');
            const [roleId] = role.split(',');
            return {
                projectId: parseInt(projectId, 10),
                roleId: parseInt(roleId, 10)
            };
        });

        try {
            await updateRoleConfig(user.id, newRoleConfigs);
            alert('Role configurations updated successfully');
            onBack(); // Use onBack to navigate back
        } catch (error) {
            console.error('Error updating role configurations:', error);
            alert('Error updating role configurations');
        }
    };

    return (
        <div>
            <h1>{user.username}</h1>

            <Grid container justifyContent="flex-end" spacing={2} style={{ marginBottom: '20px' }}>
                <Grid item>
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleSave}
                    >
                        Save
                    </Button>
                </Grid>
                <Grid item>
                    <Button
                        variant="contained"
                        color="secondary"
                        startIcon={<ArrowBackIcon />}
                        onClick={onBack}
                    >
                        Back
                    </Button>
                </Grid>
            </Grid>

            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <StyledTableCell className="header role">Roles</StyledTableCell>
                            {projects.map(project => {
                                const [projectId, projectName] = project.split(',');
                                return (
                                    <StyledTableCell key={projectId} align="center" className="header">
                                        {projectName}
                                    </StyledTableCell>
                                );
                            })}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {roles.map(role => {
                            const [roleId, roleName] = role.split(',');
                            return (
                                <TableRow key={roleId}>
                                    <StyledTableCell className="role">{roleName}</StyledTableCell>
                                    {projects.map(project => (
                                        <TableCell key={project} align="center">
                                            <FormControlLabel
                                                control={
                                                    <Radio
                                                        checked={selectedRoles[project] === role}
                                                        onChange={() => handleRadioChange(project, role)}
                                                        value={role}
                                                    />
                                                }
                                                label=""
                                            />
                                        </TableCell>
                                    ))}
                                </TableRow>
                            );
                        })}
                    </TableBody>
                </Table>
            </TableContainer>
        </div>
    );
}

export default EditUpr;
