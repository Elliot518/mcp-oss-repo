import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import { useState, useEffect } from 'react';
import { User } from '../../model/UserModels';
import { addUser } from '../../api/UserApi';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import Button from '@mui/material/Button';
import UserDialogContent from './UserDialogContent';

function AddUser() {
    const queryClient = useQueryClient();

    const initialUserState: User = {
        id: 0,
        username: '',
        password: '123456',
        pwExpiry: '',
        emailAddress: ''
    };

    const [user, setUser] = useState<User>(initialUserState);
    const [open, setOpen] = useState(false);

    const { mutate } = useMutation(addUser, {
        onSuccess: () => {
            queryClient.invalidateQueries(["users"]);
        },
        onError: (err) => {
            console.error(err);
        },
    });

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    useEffect(() => {
        if (open) {
            setUser(initialUserState);
        }
    }, [open]);

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setUser({ ...user, [event.target.name]: event.target.value });
    };

    const handleSave = () => {
        mutate(user);
        setUser(initialUserState);
        handleClose();
    };

    return (
        <>
            <Button onClick={handleClickOpen}>New User</Button>
            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>New User</DialogTitle>
                <UserDialogContent user={user} handleChange={handleChange} />
                <DialogActions>
                    <Button onClick={handleSave}>Save</Button>
                    <Button onClick={handleClose}>Cancel</Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default AddUser;
