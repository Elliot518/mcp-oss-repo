// src/components/Permissions.tsx
import React from 'react';

const Permissions: React.FC = () => {
    return <div>Permissions Component</div>;
};

export default Permissions;
