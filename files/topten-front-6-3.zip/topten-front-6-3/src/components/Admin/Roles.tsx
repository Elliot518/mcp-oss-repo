// src/components/Roles.tsx
import React from 'react';

const Roles: React.FC = () => {
    return <div>Roles Component</div>;
};

export default Roles;
