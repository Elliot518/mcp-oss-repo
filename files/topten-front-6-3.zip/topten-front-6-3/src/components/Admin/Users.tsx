import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { listAllUsers, deleteUser } from '../../api/UserApi';
import { DataGrid, GridColDef, GridToolbar, GridCellParams } from '@mui/x-data-grid';
import IconButton from '@mui/material/IconButton';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';
import Grid from '@mui/material/Grid';
import Snackbar from '@mui/material/Snackbar';
import Tooltip from '@mui/material/Tooltip';
import AddUser from './AddUser';
import EditUpr from './EditUpr';
import EditIcon from '@mui/icons-material/Edit';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';

function Users() {
    const [open, setOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState<{ id: number, username: string } | null>(null);

    const queryClient = useQueryClient();
    
    const { data, error, isSuccess } = useQuery({
        queryKey: ["users"],
        queryFn: listAllUsers,
    });

    const { mutate } = useMutation(deleteUser, {
        onSuccess: () => {
            setOpen(true);
            queryClient.invalidateQueries({ queryKey: ['users'] });
        },
        onError: (err) => {
            console.error(err);
        },
    });

    const handleRoleClick = (id: number, username: string) => {
        setSelectedUser({ id, username });
    };

    const handleBack = () => {
        setSelectedUser(null);
    };

    const columns: GridColDef[] = [
        { field: 'id', headerName: 'ID', width: 100, hide: true },
        { field: 'username', headerName: 'Username', width: 130 },
        { field: 'pwExpiry', headerName: 'Password Expiry', width: 180 },
        { field: 'emailAddress', headerName: 'Email Address', width: 180 },
        {
            field: 'delete',
            headerName: '',
            width: 90,
            sortable: false,
            filterable: false,
            disableColumnMenu: true,
            renderCell: (params: GridCellParams) => (
                <Tooltip title="Disable / Delete">
                    <IconButton aria-label="delete" size="small"
                        onClick={() => {
                            if (window.confirm(`Are you sure you want to delete ${params.row.username}?`)) {
                                mutate(params.row);
                            }
                        }}
                    >
                        <DeleteForeverIcon fontSize="small" />
                    </IconButton>
                </Tooltip>
            ),
        },
        {
            field: 'roles',
            headerName: '',
            width: 90,
            sortable: false,
            filterable: false,
            disableColumnMenu: true,
            renderCell: (params: GridCellParams) => (
                <Tooltip title="Assign roles">
                    <IconButton
                        aria-label="roles"
                        size="small"
                        onClick={() => handleRoleClick(params.row.id, params.row.username)}
                    >
                        <EditIcon fontSize="small" />
                    </IconButton>
                </Tooltip>
            ),
        }
    ];

    if (!isSuccess) {
        return <span>Loading...</span>;
    } else if (error) {
        return <span>Error when fetching users...</span>;
    } else {
        return (
            <>
                {selectedUser ? (
                    <EditUpr user={selectedUser} onBack={handleBack} />
                ) : (
                    <>
                        <Grid container justifyContent="space-between" alignItems="center">
                            <Grid item>
                                <AddUser />
                            </Grid>
                        </Grid>
                        <DataGrid
                            rows={data.data}
                            columns={columns}
                            getRowId={row => row.id}
                            slots={{ toolbar: GridToolbar }}
                        />
                    </>
                )}
                <Snackbar
                    open={open}
                    autoHideDuration={2000}
                    onClose={() => setOpen(false)}
                    message="Data deleted" />
            </>
        );
    }
}

export default Users;
