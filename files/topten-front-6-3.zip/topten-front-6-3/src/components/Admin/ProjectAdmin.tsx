// src/components/ProjectsAdmin.tsx
import React, { useState } from 'react';
import { Tabs, Tab, Box } from '@mui/material';
import Users from './Users';
import Projects from './Projects';
import Roles from './Roles';
import Permissions from './Permissions';

const ProjectsAdmin: React.FC = () => {
    const [selectedTab, setSelectedTab] = useState(0);

    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
        setSelectedTab(newValue);
    };

    const renderContent = () => {
        switch (selectedTab) {
            case 0:
                return <Users />;
            case 1:
                return <Projects />;
            case 2:
                return <Roles />;
            case 3:
                return <Permissions />;
            default:
                return null;
        }
    };

    return (
        <Box sx={{ width: '100%' }}>
            <Tabs value={selectedTab} onChange={handleChange} centered>
                <Tab label="Users" />
                <Tab label="Projects" />
                <Tab label="Roles" />
                <Tab label="Permissions" />
            </Tabs>
            <Box sx={{ p: 3 }}>
                {renderContent()}
            </Box>
        </Box>
    );
};

export default ProjectsAdmin;



