//import { parse, format } from 'date-fns-tz';

export function getISODateString() {
    // Specify the target time zone offset in minutes (e.g., -300 for 'Asia/Shanghai')
    const targetTimeZoneOffset = 480;

    // Get the current date and time in the user's local time zone
    const currentDate = new Date();

    // Adjust the date and time to the target time zone
    const targetDate = new Date(currentDate.getTime() + (targetTimeZoneOffset * 60000));

    // Convert the adjusted date to ISO string
    const isoStringWithTimeZone = targetDate.toISOString();

    return isoStringWithTimeZone;
}

export function convertToISODateString(inputDateString: string, targetTimeZone: string): string {

    if (inputDateString == null) {
        return '';
    }

    // Parse the input date string
    const [datePart, timePart] = inputDateString.split(' ');
    if (timePart == null || timePart === undefined) {
      return datePart;
    }

    const [year, month, day] = datePart.split('-').map(Number);
    const [hour, minute, second] = timePart.split(':').map(Number);
  
    // Create a Date object in the original time zone (UTC)
    const originalDate = new Date(Date.UTC(year, month - 1, day, hour, minute, second));
  
    // Convert the date to the target time zone
    const offset = Intl.DateTimeFormat().resolvedOptions().timeZone === targetTimeZone
      ? 0
      : new Date().getTimezoneOffset();
    const targetDate = new Date(originalDate.getTime() - (offset * 60000));
  
    // Format the date to ISO string
    const isoDateString = targetDate.toISOString().replace(/\.\d{3}Z$/, '.000Z');
  
    return isoDateString;
  }
