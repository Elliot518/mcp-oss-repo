export type Permission = {
    id: number;
    name: string;
    caption: string;
    created: string;
    creator: string;
    revised: string;
    revisedBy: string;
}
