// corresponds to the entity on the server side

export type FileCategory = {
    id: number;
    name: string;
    created: string;
    creator: string;
    revised: string;
    revisedBy: string;
}

