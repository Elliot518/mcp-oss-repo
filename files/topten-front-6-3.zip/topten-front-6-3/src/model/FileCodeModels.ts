// corresponds to the dto on the server side

export type FileCodeResponse = {
    id: number;
    code: string;
    name: string;
    catId: number;
    typeId: number;
    category: string;
    typeName: string;
    description: string;
    active: boolean;
    created: string;
    creator: string;
}


// corresponds to the entity on the server side

export type FileCode = {
    id: number;
    code: string;
    name: string;
    catId: number;
    typeId: number;
    description: string;
    active: boolean;
    created: string;
    creator: string;
    updated: string;
    updateBy: string;
}

// combined objects, need to be used later

export type FileCodeEntry = {
    fileCode: FileCode;
    url: string;
}