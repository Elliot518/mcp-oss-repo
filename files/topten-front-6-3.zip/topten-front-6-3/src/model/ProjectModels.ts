export type ProjectDto = {
    projectId: number;
    projectName: string;
    projectCaption: string;
    routePath: string;
    rolename: string;
    roleId: number;
}
