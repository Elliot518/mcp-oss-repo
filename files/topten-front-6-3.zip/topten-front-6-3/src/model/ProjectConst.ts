export const FILE_CODE = 'file_code';
export const DOC_CODE = 'doc_code';
export const PROJECTS_ADMIN = 'projects_admin';


export const DEFAULT_ROUTE = "/fileCode"