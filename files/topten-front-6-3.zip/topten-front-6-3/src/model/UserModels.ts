// corresponds to the entity on the server side

export type User = {
    id: number;
    username: string;
    password: string;
    pwExpiry: string;
    emailAddress: string;
}
