// corresponds to the entity on the server side

export type FileType = {
    id: number;
    typename: string;
    created: string;
    creator: string;
    revised: string;
    revisedBy: string;
}

