export const ADD = 'add';
export const EDIT = 'edit';
export const DELETE = 'delete';
export const STATUS = 'status';
