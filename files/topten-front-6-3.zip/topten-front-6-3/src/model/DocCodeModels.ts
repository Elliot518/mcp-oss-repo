// corresponds to the dto on the server side
export type DocCodeResponse = {
    id: number;
    code: string;
    name: string;
    definition: string;
    created: string;
    creator: string;
}

// corresponds to the entity on the server side
export type DocCode = {
    id: number;
    code: string;
    name: string;
    definition: string;
    created: string;
    creator: string;
    updated: string;
    updateBy: string;
}

// combined objects, need to be used later
export type DocCodeEntry = {
    docCode: DocCode;
    url: string;
}
