import axios from 'axios';
import { FileCategory } from '../model/FileCategoryModels';
import { getAxiosConfig } from './ApiRequestConfig';

export const getFileCategories = async (): Promise<FileCategory[]> => {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/api/fileCategories`, getAxiosConfig());

    return response.data;
}
