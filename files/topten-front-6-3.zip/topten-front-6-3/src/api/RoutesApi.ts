// src/api/RoutesApi.ts
import axios from 'axios';
import { ProjectDto } from '../model/ProjectModels';
import { getAxiosConfig } from './ApiRequestConfig';

export const fetchRoutes = async (userId: number) => {
    try {
        const response = await axios.get(
            `${import.meta.env.VITE_API_URL}/api/projects`,
            {
                ...getAxiosConfig(),
                params: { userId }
            }
        );

        // Check if the response is in the expected format
        if (response.data && response.data.code === "0" && Array.isArray(response.data.data)) {
            return response.data.data as ProjectDto[];
        } else {
            console.error("Unexpected response format:", response.data);
            return [];
        }
    } catch (error) {
        console.error("Error fetching operations:", error);
        throw error;
    }
};
