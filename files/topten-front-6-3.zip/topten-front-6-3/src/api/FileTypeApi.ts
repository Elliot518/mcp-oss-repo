import axios from 'axios';
import { FileType } from '../model/FileTypeModels';
import { getAxiosConfig } from './ApiRequestConfig';

export const getFileTypes = async (): Promise<FileType[]> => {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/api/fileTypes`, getAxiosConfig());

    return response.data;
}
