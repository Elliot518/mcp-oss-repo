import axios from 'axios';
import { getAxiosConfig } from './ApiRequestConfig';

export const getMatrixData = async (userId: number): Promise<any> => {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/api/admin/roleMatrix`, {
        ...getAxiosConfig(),
        params: { userId }
    });

    return response.data;
};

export const updateRoleConfig = async (userId: number, roleConfigs: { projectId: number, roleId: number }[]) => {
    const response = await axios.put(`${import.meta.env.VITE_API_URL}/api/admin/upr`, roleConfigs, {
        ...getAxiosConfig(),
        params: { userId }
    });

    return response.data;
};
