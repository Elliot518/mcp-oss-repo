import axios from 'axios';
import { User } from '../model/UserModels';
import { getAxiosConfig } from './ApiRequestConfig';

// call get api
export const listAllUsers = async (): Promise<User[]> => {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/api/users`, getAxiosConfig())

    return response.data;
}

export const addUser = async (user: User) => {
    const response = await axios.post(`${import.meta.env.VITE_API_URL}/api/users`, user, getAxiosConfig());
    return response.data;
};

export const updateUser = async (user: User) => {
    const response = await axios.put(`${import.meta.env.VITE_API_URL}/api/users/${user.id}`, user, getAxiosConfig());
    return response.data;
};

export const deleteUser = async (user: User) => {
    const response = await axios.delete(`${import.meta.env.VITE_API_URL}/api/userEntities/${user.id}`, getAxiosConfig());
    return response.data;
};
