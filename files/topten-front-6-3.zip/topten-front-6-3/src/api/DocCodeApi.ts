import axios from 'axios';
import { DocCode, DocCodeResponse } from '../model/DocCodeModels';
import { getAxiosConfig } from './ApiRequestConfig';

// call listAllDocCodes from the API of server side
export const listAllDocCodes = async (): Promise<DocCodeResponse[]> => {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/api/docCodes`, getAxiosConfig())

    return response.data;
}

// call delete api
export const deleteDocCode = async (docCodeResponse: DocCodeResponse): Promise<DocCodeResponse> => {
    const link = `${import.meta.env.VITE_API_URL}/api/docCodeEntities/${docCodeResponse.id}`;
    const response = await axios.delete(link, getAxiosConfig());
    return response.data;
}

// call add api
export const addDocCode = async (docCode: DocCode): Promise<DocCodeResponse> => {
    const response = await axios.post(`${import.meta.env.VITE_API_URL}/api/docCodeEntities`, docCode, getAxiosConfig());

    return response.data;
}

// call update api
export const updateDocCode = async (docCode: DocCode): Promise<DocCodeResponse> => {
    const link = `${import.meta.env.VITE_API_URL}/api/docCodeEntities/${docCode.id}`;
    const response = await axios.put(link, docCode, getAxiosConfig());

    return response.data;
}
