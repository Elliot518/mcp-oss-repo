import axios from 'axios';
import { FileCode, FileCodeResponse } from '../model/FileCodeModels';
import { getAxiosConfig } from './ApiRequestConfig';

// call listAllFileCodes from the API of server side
export const listAllFileCodes = async (): Promise<FileCodeResponse[]> => {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/api/fileCodes`, getAxiosConfig())

    return response.data;
}

// call delete api
export const deleteFileCode = async (fileCodeResponse: FileCodeResponse): Promise<FileCodeResponse> => {
    const link = `${import.meta.env.VITE_API_URL}/api/fileCodeEntities/${fileCodeResponse.id}`;
    const response = await axios.delete(link, getAxiosConfig());
    return response.data
}

// call add api
export const addFileCode = async (fileCode: FileCode): Promise<FileCodeResponse> => {
    const response = await axios.post(`${import.meta.env.VITE_API_URL}/api/fileCodeEntities`, fileCode, getAxiosConfig());

    return response.data;
}

// call update api
export const updateFileCode = async (fileCode: FileCode): Promise<FileCodeResponse> => {
    const link = `${import.meta.env.VITE_API_URL}/api/fileCodeEntities/${fileCode.id}`;
    const response = await axios.put(link, fileCode, getAxiosConfig());

    return response.data;
}


