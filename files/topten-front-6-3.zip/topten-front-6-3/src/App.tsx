// src/App.tsx

import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import CssBaseline from '@mui/material/CssBaseline';
import Container from '@mui/material/Container';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Login from './components/Login';
import ProtectedRoutes from './components/ProtectedRoutes';
import ProtectedLayout from './components/ProtectedLayout'; // Ensure the correct path
import './styles.css'; // Import the custom CSS file

const queryClient = new QueryClient();

function App() {
    return (
        <div>
            <CssBaseline />
            <Container maxWidth="xl" className="custom-container">
                <QueryClientProvider client={queryClient}>
                    <Router>
                        <Routes>
                            <Route path="/" element={<Navigate to="/login" />} />
                            <Route path="/login" element={<Login />} />
                            <Route element={<ProtectedRoutes />}>
                                <Route path="/*" element={<ProtectedLayout />} />
                            </Route>
                        </Routes>
                    </Router>
                </QueryClientProvider>
            </Container>
        </div>
    );
}

export default App;
