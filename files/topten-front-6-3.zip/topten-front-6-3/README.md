### 1. Install Dependencies

```
npm install react-router-dom
npm install bcryptjs
```